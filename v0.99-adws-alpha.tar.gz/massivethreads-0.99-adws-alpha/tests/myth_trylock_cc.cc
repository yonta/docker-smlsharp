#include "myth_trylock.c"
