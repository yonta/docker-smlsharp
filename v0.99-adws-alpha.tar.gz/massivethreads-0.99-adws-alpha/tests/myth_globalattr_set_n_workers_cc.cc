#include "myth_globalattr_set_n_workers.c"
