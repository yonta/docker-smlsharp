#include "myth_create_join_many.c"
